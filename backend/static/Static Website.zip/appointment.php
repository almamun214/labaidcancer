<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Appointment || Labaid Cancer Hospital and Super Specialty Center</title>
    <link rel="manifest" href="images/favicon/manifest.json">
    <link rel="stylesheet" href="css/all-styles.css">

</head>


<body>
    <div class="preloader"></div>
    <div class="page-wrapper">
        <?php include('header.php'); ?>


        <section class="cancer-details">
            <div class="container">
                <div class="row">
                    <div class="col-12 col-lg-3" style="height: 900px;background: red;">
                        
                    </div>
                    <div class="col-12 col-lg-9" style="height: 900px;background: blue;">
                        
                    </div>
                </div>
            </div><!-- /.container -->
        </section>


<?php include('footer.php'); ?>